package com.ExTema1;

public class ExTema1 {

    public static void main(String[] args) {
        // 1. numericos



        // 1.1 enteros
        byte variable1 = 4;
        System.out.println(variable1);

        short variable2 = 5;
        System.out.println(variable2);

        int variable3 = 6;
        System.out.println(variable3);

        long variable4 = 7;
        System.out.println(variable4);

        long numeroTelefono = 666888777;
        System.out.println(numeroTelefono);

        // 1.2 decimales
        float variable5 = 8.5f;
        System.out.println(variable5);

        double variable6 = 20.5d;
        System.out.println(variable6);

        // 2.booleano
        boolean variable7 = false;
        System.out.println(variable7);

        boolean variable8 = true;
        System.out.println(variable8);

        // 3.texto
        char variable9 = 'b';
        System.out.println(variable9);

        String variable10 = "Estoy imprimiendo una frase";
        System.out.println(variable10);
    }
}
